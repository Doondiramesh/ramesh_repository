sh /tch/codedeployments_github/scripts/stop_server.sh
sh /tch/codedeployments_github/scripts/backup_old_build.sh
sh /tch/codedeployments_github/scripts/copy_latest_build.sh
sh /tch/codedeployments_github/scripts/start_server.sh
